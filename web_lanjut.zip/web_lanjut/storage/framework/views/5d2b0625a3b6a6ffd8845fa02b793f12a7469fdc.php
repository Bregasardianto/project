<?php $__env->startSection('Content'); ?>
<div class="page-header">
    <div class="page-header-content">
        <div>
            <h4 class="">
                <i class="icon-home position-left"></i>
                <span class="text-semibold"> Daftar Obat</span></h4>
            <a class="heading-elements-toggle">
                <i class="icon-more"></i>
            </a>
        </div>
        <div class="heading-elements">
            <ul class="breadcrumb position-right">
                <li>
                    <a href="<?php echo e(route('apotek.index')); ?>">Home</a>
                </li>
                <li>
                    <a href="">Apotek</a>
                </li>
                <li class="active">Daftar Obat</li>
            </ul>
        </div>
    </div>
    <!-- /header content -->
</div>
<div class="content">
    <div class="panel panel-flat  border-top-lg border-top-primary">
        <div class="panel-body">
            <table class="table table-bordered">

            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web_lanjut\resources\views/admin/apotek.blade.php ENDPATH**/ ?>